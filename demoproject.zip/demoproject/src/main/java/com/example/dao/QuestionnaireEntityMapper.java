package com.example.dao;

import com.example.dao.entity.QuestionnaireEntity;

import java.util.List;

public interface QuestionnaireEntityMapper {
    /**
     * 查询问卷列表，文卷编辑页面的显示
     **/
    List<QuestionnaireEntity> queryUserList(QuestionnaireEntity questionnaireEntity);

    /**
     * 创建用户的基本信息
     **/
    int insert(QuestionnaireEntity questionnaireEntityr);
    /*
     *根据id删除用户信息
     */
    int deleteUserById(QuestionnaireEntity questionnaireEntity);
    /*
    编辑用户信息
     */
    int updateByPrimaryKeySelective(QuestionnaireEntity questionnaireEntity);
    /*
    查询用户
     */
    List<QuestionnaireEntity> selectUserInfo(QuestionnaireEntity questionnaireEntity);
}
