package com.example.dao.entity;

import java.io.Serializable;

public class XuanxiangEntity implements Serializable {
    private String id;
    private String questionId;
    private String optionContent;
    private String optionOrder;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public String getOptionContent() {
        return optionContent;
    }

    public void setOptionContent(String optionContent) {
        this.optionContent = optionContent;
    }

    public String getOptionOrder() {
        return optionOrder;
    }

    public void setOptionOrder(String optionOrder) {
        this.optionOrder = optionOrder;
    }

    @Override
    public String toString() {
        return "XuanxiangEntity{" +
                "id='" + id + '\'' +
                ", questionId='" + questionId + '\'' +
                ", optionContent='" + optionContent + '\'' +
                ", optionOrder='" + optionOrder + '\'' +
                '}';
    }
}
