package com.example.dao.entity;

public class QuestionnaireEntity {
    private String uid;
    private String questionnairetype;
    private String questionnairecontent;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getQuestionnairetype() {
        return questionnairetype;
    }

    public void setQuestionnairetype(String questionnairetype) {
        this.questionnairetype = questionnairetype;
    }

    public String getQuestionnairecontent() {
        return questionnairecontent;
    }

    public void setQuestionnairecontent(String questionnairecontent) {
        this.questionnairecontent = questionnairecontent;
    }

    @Override
    public String toString() {
        return "QuestionnaireEntity{" +
                "uid='" + uid + '\'' +
                ", questionnairetype='" + questionnairetype + '\'' +
                ", questionnairecontent='" + questionnairecontent + '\'' +
                '}';
    }
}