package com.example.service;

import com.example.common.utils.UUIDUtil;
import com.example.dao.XuanxiangEntityMapper;
import com.example.dao.entity.UserEntity;
import com.example.dao.entity.XuanxiangEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class XuanxiangService {
    @Autowired
    private XuanxiangEntityMapper xuanxiangEntityMapper;
    /*
    创建用户
     */
    public int addOption(XuanxiangEntity xuanxiangEntity){
        xuanxiangEntity.setId(UUIDUtil.getOneUUID());

        int xuanxiangResult = xuanxiangEntityMapper.insertXuanxiang(xuanxiangEntity);
        if (xuanxiangResult != 0){
            return 3;//数字3表示用户存在
        }else{
            return xuanxiangResult;
        }
    }
    /*
    修改用户信息
     */
    public int modifyXuanxiangInfo(XuanxiangEntity xuanxiangEntity){
        int xuanxiangResult = xuanxiangEntityMapper.modifyXuanxiangInfo(xuanxiangEntity);
        return xuanxiangResult;
    }
    /*
    删除用户信息
     */
    public int deleteXuanxiangById(XuanxiangEntity xuanxiangEntity){
        int xuanxiangResult = xuanxiangEntityMapper.deleteXuanxiangById(xuanxiangEntity);
        return xuanxiangResult;
    }
    /*
    查询用户列表
     */
    public List<XuanxiangEntity> queryXuanxiangList(XuanxiangEntity xuanxiangEntity){

        List<XuanxiangEntity> xuanxiangResult = xuanxiangEntityMapper.queryXuanxiangList(xuanxiangEntity);

        return xuanxiangResult;

    }
}
