package com.example.service;

import com.example.common.utils.UUIDUtil;
import com.example.dao.ProjectEntityMapper;
import com.example.dao.entity.ProjectEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProjectService {
    @Autowired
    private ProjectEntityMapper projectEntityMapper;
    public List<ProjectEntity> selectProjectInfo(ProjectEntity projectEntity){
        List<ProjectEntity> result = projectEntityMapper.selectProjectInfo(projectEntity);
    return result;
    }
    /*
    查询项目列表
     */
        public List<ProjectEntity> queryProjectList(ProjectEntity projectEntity){

            List<ProjectEntity> result = projectEntityMapper.queryProjectList(projectEntity);

        return result;

    }
    /*
    创建项目
     */
    public int addProjectInfo(ProjectEntity projectEntity){
        projectEntity.setId(UUIDUtil.getOneUUID());

        int projectResult = projectEntityMapper.insertProject(projectEntity);
        if (projectResult != 0){
            return 3;//数字3表示用户存在
        }else{
            return projectResult;
        }
    }
    /*
    修改用户信息
     */
    public int modifyProjectInfo(ProjectEntity projectEntity){
        int projectResult = projectEntityMapper.updateByPrimaryKeySelective(projectEntity);
        return projectResult;
    }
    /*
    删除用户信息
     */
    public int deleteProjectById(ProjectEntity projectEntity){
        int projectResult = projectEntityMapper.deleteProjectById(projectEntity);
        return projectResult;
    }
}
