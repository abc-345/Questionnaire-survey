const handleConfirmModify = () => {
  $('#modifyTitleModal').modal('hide')
  $('.questionnaire-title > span').text(questionName)
  $('.questionnaire-description > span').text(questionType)
}

const onQuestionnaireTitleInput = (e) => {
  questionName = e.value
}

const onQuestionnaireDescriptionInput = (e) => {
  questionType = e.value
}
